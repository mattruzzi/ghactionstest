# nativefier-gui

Graphical user interface for [nativefier](https://github.com/nativefier/nativefier).
![](screenshot.png)
